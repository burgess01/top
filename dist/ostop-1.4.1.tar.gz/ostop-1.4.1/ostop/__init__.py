"""ostop is a cross-compatible Python implementation of the top command."""
